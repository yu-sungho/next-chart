<template>
  <section class="single-recipe">
      <h1>TITLE</h1>
    <dib>
        <img src="" alt="">
    </dib>
    <p>The recipe description.</p>
  </section>
</template>

<style scoped>
    .single-recipe {
        display: flex;
        flex-flow: row wrap;
        justify-content: center;
        

    }
</style>
