<template>
  <section class="recipes">
      <Recipe
        v-for="recipe in recipes"
        :key="recipe.id"
        :thumbnail="recipe.thumbnail"
        :title="recipe.title"
        :id="recipe.id"
        :previewText="recipe.previewText"
        />
  </section>
</template>

<script>
import Recipe from '@/components/Recipe'

export default {
    components: {
        Recipe
    },
    asyncData() {
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                resolve({
                    recipes: [
                        {
                            id:"1", 
                            title: "Delicious Pizza",
                            previewText: "Awesome Pizza!"
                        }
                    ]
                });
            }, 1500)
        })
    }
}
</script>


<style scoped>
.recipes {
    display:flex;
    flex-flow: row wrap;

}

.recipe {
    box-sizing: border-box;
    width:280px;
    padding: 8px;
    border: 1px solid #ccc;
    box-shadow: 0 2px 2px #aaa;
}
</style>

