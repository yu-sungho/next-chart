<template>
    <article class="recipe">
        <div></div>
        <h1>Title</h1>
        <p>Some nice preview text</p>
    </article>
</template>
